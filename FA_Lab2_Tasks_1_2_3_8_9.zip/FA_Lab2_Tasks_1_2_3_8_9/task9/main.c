#include <float.h>
#include <limits.h>
#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

typedef enum {
    STATUS_OK = 0,
    STATUS_INVALID_ARGUMENT,
    STATUS_OVERFLOW,
    STATUS_MEMORY_ERROR,
    STATUS_CONVERSION_ERROR,
    STATUS_OUTPUT_ERROR
} Status;

static bool is_decimal_text(const char *text) {
    if (text == NULL || text[0] == '\0') {
        return false;
    }
    const char *p = text;
    if (*p == '+' || *p == '-') {
        ++p;
    }
    bool has_digit = false;
    while (*p >= '0' && *p <= '9') {
        has_digit = true;
        ++p;
    }
    if (*p == '.') {
        ++p;
        while (*p >= '0' && *p <= '9') {
            has_digit = true;
            ++p;
        }
    }
    if (!has_digit) {
        return false;
    }
    if (*p == 'e' || *p == 'E') {
        ++p;
        if (*p == '+' || *p == '-') {
            ++p;
        }
        if (*p < '0' || *p > '9') {
            return false;
        }
        while (*p >= '0' && *p <= '9') {
            ++p;
        }
    }
    return *p == '\0';
}

static Status parse_base(const char *text, unsigned int *result) {
    if (text == NULL || result == NULL || *text == '\0') {
        return STATUS_INVALID_ARGUMENT;
    }
    unsigned int base = 0;
    for (size_t i = 0; text[i] != '\0'; ++i) {
        if (text[i] < '0' || text[i] > '9') {
            return STATUS_INVALID_ARGUMENT;
        }
        base = base * 10U + (unsigned int)(text[i] - '0');
        if (base > 36U) {
            return STATUS_INVALID_ARGUMENT;
        }
    }
    if (base < 2U) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = base;
    return STATUS_OK;
}

/* Convert a decimal literal in the form 1.25e-3 to M * 10^exponent. */
static Status parse_decimal_rational(const char *text,
                                     unsigned long long *mantissa,
                                     int *power10) {
    if (text == NULL || mantissa == NULL || power10 == NULL ||
        !is_decimal_text(text)) {
        return STATUS_INVALID_ARGUMENT;
    }
    const char *p = text;
    if (*p == '+') {
        ++p;
    }
    if (*p == '-') {
        return STATUS_INVALID_ARGUMENT;
    }
    unsigned long long number = 0;
    int decimal_places = 0;
    bool after_point = false;
    while ((*p >= '0' && *p <= '9') || *p == '.') {
        if (*p == '.') {
            after_point = true;
        } else {
            unsigned int digit = (unsigned int)(*p - '0');
            if (number > (ULLONG_MAX - digit) / 10ULL) {
                return STATUS_OVERFLOW;
            }
            number = number * 10ULL + digit;
            if (after_point) {
                if (decimal_places == INT_MAX) {
                    return STATUS_OVERFLOW;
                }
                ++decimal_places;
            }
        }
        ++p;
    }
    int exponent = 0;
    if (*p == 'e' || *p == 'E') {
        ++p;
        bool negative = false;
        if (*p == '+' || *p == '-') {
            negative = *p == '-';
            ++p;
        }
        while (*p >= '0' && *p <= '9') {
            unsigned int digit = (unsigned int)(*p - '0');
            if (exponent > (INT_MAX - (int)digit) / 10) {
                return STATUS_OVERFLOW;
            }
            exponent = exponent * 10 + (int)digit;
            ++p;
        }
        if (negative) {
            exponent = -exponent;
        }
    }
    if (exponent < INT_MIN + decimal_places) {
        return STATUS_OVERFLOW;
    }
    *mantissa = number;
    *power10 = exponent - decimal_places;
    return STATUS_OK;
}

/* Choose the shortest decimal representation that maps back to the same
   double. For example, the double produced by 0.1 is interpreted as the
   original decimal fraction 1/10, not as its exact binary approximation. */
static Status decimal_from_double(double value, double epsilon,
                                  unsigned long long *mantissa,
                                  int *power10) {
    if (mantissa == NULL || power10 == NULL || !isfinite(value) ||
        value <= 0.0 || value >= 1.0 || !isfinite(epsilon) || epsilon < 0.0) {
        return STATUS_INVALID_ARGUMENT;
    }
    char buffer[128];
    for (int precision = 1; precision <= DBL_DECIMAL_DIG; ++precision) {
        int n = snprintf(buffer, sizeof(buffer), "%.*g", precision, value);
        if (n < 0 || (size_t)n >= sizeof(buffer)) {
            return STATUS_CONVERSION_ERROR;
        }
        char *end = NULL;
        double decoded = strtod(buffer, &end);
        if (end != NULL && *end == '\0' && isfinite(decoded) &&
            fabs(decoded - value) <= epsilon) {
            return parse_decimal_rational(buffer, mantissa, power10);
        }
    }
    return STATUS_CONVERSION_ERROR;
}

/* A rational number has a finite representation in base b exactly when
   each prime factor of its reduced denominator divides b. Here the original
   decimal denominator can only contain 2 and 5. */
static Status is_terminating(double value, unsigned int base, double epsilon,
                             bool *result) {
    if (result == NULL || base < 2U || base > 36U) {
        return STATUS_INVALID_ARGUMENT;
    }
    unsigned long long numerator = 0;
    int power10 = 0;
    Status status = decimal_from_double(value, epsilon, &numerator, &power10);
    if (status != STATUS_OK) {
        return status;
    }
    if (numerator == 0 || power10 >= 0 || power10 == INT_MIN) {
        return STATUS_INVALID_ARGUMENT;
    }

    int need_two = -power10;
    int need_five = -power10;
    while (need_two > 0 && numerator % 2ULL == 0ULL) {
        numerator /= 2ULL;
        --need_two;
    }
    while (need_five > 0 && numerator % 5ULL == 0ULL) {
        numerator /= 5ULL;
        --need_five;
    }
    *result = (need_two == 0 || base % 2U == 0U) &&
              (need_five == 0 || base % 5U == 0U);
    return STATUS_OK;
}

/* Required variadic function: base, epsilon, count and decimal fractions. */
static Status check_fractions(unsigned int base, double epsilon,
                              size_t count, bool **results, ...) {
    if (results == NULL || base < 2U || base > 36U || count == 0 ||
        count > SIZE_MAX / sizeof(bool) ||
        !isfinite(epsilon) || epsilon < 0.0) {
        return STATUS_INVALID_ARGUMENT;
    }
    *results = NULL;
    bool *values = malloc(count * sizeof(*values));
    if (values == NULL) {
        return STATUS_MEMORY_ERROR;
    }
    Status status = STATUS_OK;
    va_list args;
    va_start(args, results);
    for (size_t i = 0; i < count; ++i) {
        double value = va_arg(args, double);
        status = is_terminating(value, base, epsilon, &values[i]);
        if (status != STATUS_OK) {
            break;
        }
    }
    va_end(args);
    if (status != STATUS_OK) {
        free(values);
        return status;
    }
    *results = values;
    return STATUS_OK;
}

static const char *status_message(Status status) {
    switch (status) {
        case STATUS_OK: return "success";
        case STATUS_INVALID_ARGUMENT: return "invalid base, precision or fraction";
        case STATUS_OVERFLOW: return "number size overflow";
        case STATUS_MEMORY_ERROR: return "out of memory";
        case STATUS_CONVERSION_ERROR: return "cannot convert decimal fraction";
        case STATUS_OUTPUT_ERROR: return "cannot write result";
    }
    return "unknown error";
}

int main(int argc, char *argv[]) {
    if (argc < 3 || argv == NULL || argv[1] == NULL) {
        fprintf(stderr, "Usage: %s BASE FRACTION [FRACTION ...]\n",
                argc > 0 && argv != NULL ? argv[0] : "task9");
        return EXIT_FAILURE;
    }
    unsigned int base = 0;
    Status status = parse_base(argv[1], &base);
    if (status != STATUS_OK) {
        fprintf(stderr, "Error: base must be in [2, 36]\n");
        return EXIT_FAILURE;
    }

    /* A function with ... cannot be invoked with a runtime-created argument
       list, so supply up to four double arguments per call. */
    for (int i = 2; i < argc;) {
        size_t count = argc - i > 4 ? 4U : (size_t)(argc - i);
        double values[4] = {0.0, 0.0, 0.0, 0.0};
        for (size_t j = 0; j < count; ++j) {
            const char *text = argv[i + (int)j];
            if (!is_decimal_text(text)) {
                status = STATUS_INVALID_ARGUMENT;
                break;
            }
            char *end = NULL;
            values[j] = strtod(text, &end);
            if (end == NULL || *end != '\0' || !isfinite(values[j]) ||
                values[j] <= 0.0 || values[j] >= 1.0) {
                status = STATUS_INVALID_ARGUMENT;
                break;
            }
        }
        if (status != STATUS_OK) {
            break;
        }
        bool *results = NULL;
        switch (count) {
            case 1:
                status = check_fractions(base, 0.0, 1, &results, values[0]);
                break;
            case 2:
                status = check_fractions(base, 0.0, 2, &results,
                                         values[0], values[1]);
                break;
            case 3:
                status = check_fractions(base, 0.0, 3, &results,
                                         values[0], values[1], values[2]);
                break;
            case 4:
                status = check_fractions(base, 0.0, 4, &results,
                                         values[0], values[1], values[2],
                                         values[3]);
                break;
            default:
                status = STATUS_INVALID_ARGUMENT;
                break;
        }
        if (status == STATUS_OK) {
            for (size_t j = 0; j < count; ++j) {
                if (printf("%s -> %s in base %u\n", argv[i + (int)j],
                           results[j] ? "finite" : "infinite", base) < 0) {
                    status = STATUS_OUTPUT_ERROR;
                    break;
                }
            }
        }
        free(results);
        if (status != STATUS_OK) {
            break;
        }
        i += (int)count;
    }
    if (status == STATUS_OK && fflush(stdout) == EOF) {
        status = STATUS_OUTPUT_ERROR;
    }
    if (status != STATUS_OK) {
        fprintf(stderr, "Error: %s\n", status_message(status));
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
