#include <ctype.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef enum {
    STATUS_OK = 0,
    STATUS_INVALID_ARGUMENT,
    STATUS_OVERFLOW,
    STATUS_MEMORY_ERROR
} Status;

/* All string operations here are implemented without string.h. */
static Status get_string_length(const char *text, size_t *length) {
    if (text == NULL || length == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }

    size_t count = 0;
    while (text[count] != '\0') {
        if (count == SIZE_MAX) {
            return STATUS_OVERFLOW;
        }
        ++count;
    }
    *length = count;
    return STATUS_OK;
}

static Status allocate_string(size_t length, char **result) {
    if (result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    if (length == SIZE_MAX) {
        return STATUS_OVERFLOW;
    }
    *result = malloc(length + 1);
    return *result != NULL ? STATUS_OK : STATUS_MEMORY_ERROR;
}

static Status reverse_string(const char *text, char **result) {
    if (text == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;

    size_t length = 0;
    Status status = get_string_length(text, &length);
    if (status != STATUS_OK) {
        return status;
    }
    status = allocate_string(length, result);
    if (status != STATUS_OK) {
        return status;
    }

    for (size_t i = 0; i < length; ++i) {
        (*result)[i] = text[length - i - 1];
    }
    (*result)[length] = '\0';
    return STATUS_OK;
}

static Status uppercase_odd_positions(const char *text, char **result) {
    if (text == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;

    size_t length = 0;
    Status status = get_string_length(text, &length);
    if (status != STATUS_OK) {
        return status;
    }
    status = allocate_string(length, result);
    if (status != STATUS_OK) {
        return status;
    }

    for (size_t i = 0; i < length; ++i) {
        unsigned char ch = (unsigned char)text[i];
        (*result)[i] = (i % 2 != 0) ? (char)toupper(ch) : text[i];
    }
    (*result)[length] = '\0';
    return STATUS_OK;
}

static Status group_characters(const char *text, char **result) {
    if (text == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;

    size_t length = 0;
    Status status = get_string_length(text, &length);
    if (status != STATUS_OK) {
        return status;
    }
    status = allocate_string(length, result);
    if (status != STATUS_OK) {
        return status;
    }

    size_t write_pos = 0;
    for (size_t i = 0; i < length; ++i) {
        if (isdigit((unsigned char)text[i])) {
            (*result)[write_pos++] = text[i];
        }
    }
    for (size_t i = 0; i < length; ++i) {
        if (isalpha((unsigned char)text[i])) {
            (*result)[write_pos++] = text[i];
        }
    }
    for (size_t i = 0; i < length; ++i) {
        unsigned char ch = (unsigned char)text[i];
        if (!isdigit(ch) && !isalpha(ch)) {
            (*result)[write_pos++] = text[i];
        }
    }
    (*result)[write_pos] = '\0';
    return STATUS_OK;
}

static Status parse_seed(const char *text, unsigned int *seed) {
    if (text == NULL || seed == NULL || *text == '\0') {
        return STATUS_INVALID_ARGUMENT;
    }
    size_t i = 0;
    if (text[i] == '+') {
        ++i;
        if (text[i] == '\0') {
            return STATUS_INVALID_ARGUMENT;
        }
    }

    unsigned int number = 0;
    for (; text[i] != '\0'; ++i) {
        if (text[i] < '0' || text[i] > '9') {
            return STATUS_INVALID_ARGUMENT;
        }
        unsigned int digit = (unsigned int)(text[i] - '0');
        if (number > (UINT_MAX - digit) / 10U) {
            return STATUS_OVERFLOW;
        }
        number = number * 10U + digit;
    }
    *seed = number;
    return STATUS_OK;
}

static Status concatenate_random(const char *const *strings, size_t count,
                                 unsigned int seed, char **result) {
    if (strings == NULL || result == NULL || count == 0) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    if (count > SIZE_MAX / sizeof(size_t)) {
        return STATUS_OVERFLOW;
    }

    size_t *order = malloc(count * sizeof(*order));
    if (order == NULL) {
        return STATUS_MEMORY_ERROR;
    }

    size_t total_length = 0;
    Status status = STATUS_OK;
    for (size_t i = 0; i < count; ++i) {
        size_t current_length = 0;
        status = get_string_length(strings[i], &current_length);
        if (status != STATUS_OK) {
            break;
        }
        if (current_length > SIZE_MAX - total_length) {
            status = STATUS_OVERFLOW;
            break;
        }
        total_length += current_length;
        order[i] = i;
    }

    if (status == STATUS_OK) {
        /* Fisher-Yates shuffle; seed is supplied as the third CLI argument. */
        srand(seed);
        for (size_t i = count - 1; i > 0; --i) {
            size_t j = (size_t)rand() % (i + 1);
            size_t temporary = order[i];
            order[i] = order[j];
            order[j] = temporary;
        }

        status = allocate_string(total_length, result);
        if (status == STATUS_OK) {
            size_t pos = 0;
            for (size_t i = 0; i < count; ++i) {
                const char *part = strings[order[i]];
                for (size_t j = 0; part[j] != '\0'; ++j) {
                    (*result)[pos++] = part[j];
                }
            }
            (*result)[pos] = '\0';
        }
    }

    free(order);
    return status;
}

static const char *status_description(Status status) {
    switch (status) {
        case STATUS_OK: return "success";
        case STATUS_INVALID_ARGUMENT: return "invalid argument";
        case STATUS_OVERFLOW: return "integer or size overflow";
        case STATUS_MEMORY_ERROR: return "memory allocation failed";
    }
    return "unknown error";
}

static void print_usage(const char *program) {
    fprintf(stderr,
            "Usage:\n"
            "  %s -l STRING\n"
            "  %s -r STRING\n"
            "  %s -u STRING\n"
            "  %s -n STRING\n"
            "  %s -c STRING SEED [STRING ...]\n",
            program, program, program, program, program);
}

int main(int argc, char *argv[]) {
    if (argc < 3 || argv == NULL || argv[0] == NULL || argv[1] == NULL) {
        print_usage(argc > 0 && argv != NULL && argv[0] != NULL ? argv[0] : "task1");
        return EXIT_FAILURE;
    }

    const char *flag = argv[1];
    if (flag[0] != '-' || flag[1] == '\0' || flag[2] != '\0') {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    Status status = STATUS_INVALID_ARGUMENT;
    char *result = NULL;
    size_t length = 0;
    if (flag[1] == 'l' && argc == 3) {
        status = get_string_length(argv[2], &length);
    } else if (flag[1] == 'r' && argc == 3) {
        status = reverse_string(argv[2], &result);
    } else if (flag[1] == 'u' && argc == 3) {
        status = uppercase_odd_positions(argv[2], &result);
    } else if (flag[1] == 'n' && argc == 3) {
        status = group_characters(argv[2], &result);
    } else if (flag[1] == 'c' && argc >= 4) {
        unsigned int seed = 0;
        status = parse_seed(argv[3], &seed);
        if (status == STATUS_OK) {
            size_t count = (size_t)(argc - 3);
            if (count > SIZE_MAX / sizeof(const char *)) {
                status = STATUS_OVERFLOW;
            } else {
                const char **strings = malloc(count * sizeof(*strings));
                if (strings == NULL) {
                    status = STATUS_MEMORY_ERROR;
                } else {
                    strings[0] = argv[2];
                    for (size_t i = 1; i < count; ++i) {
                        strings[i] = argv[i + 3];
                    }
                    status = concatenate_random(strings, count, seed, &result);
                    free(strings);
                }
            }
        }
    } else {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    if (status != STATUS_OK) {
        fprintf(stderr, "Error: %s\n", status_description(status));
        free(result);
        return EXIT_FAILURE;
    }

    int output_result;
    if (flag[1] == 'l') {
        output_result = printf("%zu\n", length);
    } else {
        output_result = printf("%s\n", result);
    }
    free(result);
    if (output_result < 0 || fflush(stdout) == EOF) {
        fprintf(stderr, "Error: failed to write to stdout\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
