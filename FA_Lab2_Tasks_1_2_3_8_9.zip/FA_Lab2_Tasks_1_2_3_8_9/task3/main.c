#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    STATUS_OK = 0,
    STATUS_INVALID_ARGUMENT,
    STATUS_OVERFLOW,
    STATUS_MEMORY_ERROR,
    STATUS_FILE_OPEN_ERROR,
    STATUS_FILE_READ_ERROR,
    STATUS_FILE_CLOSE_ERROR,
    STATUS_OUTPUT_ERROR
} Status;

typedef struct {
    size_t line;
    size_t column;
} Match;

typedef struct {
    const char *filename; /* Borrowed pointer; do not free. */
    Match *matches;
    size_t count;
    size_t capacity;
} FileMatches;

static void free_results(FileMatches *files, size_t count) {
    if (files != NULL) {
        for (size_t i = 0; i < count; ++i) {
            free(files[i].matches);
        }
    }
    free(files);
}

/* Read the entire file, preserving tabs, spaces and newlines. */
static Status read_file(const char *filename, unsigned char **data,
                        size_t *length) {
    if (filename == NULL || filename[0] == '\0' || data == NULL || length == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *data = NULL;
    *length = 0;

    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        return STATUS_FILE_OPEN_ERROR;
    }

    size_t capacity = 4096;
    unsigned char *buffer = malloc(capacity);
    Status status = buffer == NULL ? STATUS_MEMORY_ERROR : STATUS_OK;
    size_t used = 0;
    while (status == STATUS_OK) {
        if (used == capacity) {
            if (capacity > SIZE_MAX / 2) {
                status = STATUS_OVERFLOW;
                break;
            }
            size_t new_capacity = capacity * 2;
            unsigned char *grown = realloc(buffer, new_capacity);
            if (grown == NULL) {
                status = STATUS_MEMORY_ERROR;
                break;
            }
            buffer = grown;
            capacity = new_capacity;
        }
        size_t received = fread(buffer + used, 1, capacity - used, file);
        used += received;
        if (received == 0) {
            if (ferror(file)) {
                status = STATUS_FILE_READ_ERROR;
            }
            break;
        }
    }

    if (fclose(file) != 0 && status == STATUS_OK) {
        status = STATUS_FILE_CLOSE_ERROR;
    }
    if (status != STATUS_OK) {
        free(buffer);
        return status;
    }
    *data = buffer;
    *length = used;
    return STATUS_OK;
}

static Status append_match(FileMatches *result, size_t line, size_t column) {
    if (result == NULL || line == 0 || column == 0) {
        return STATUS_INVALID_ARGUMENT;
    }
    if (result->count == result->capacity) {
        size_t maximum = SIZE_MAX / sizeof(Match);
        if (result->capacity == maximum) {
            return STATUS_OVERFLOW;
        }
        size_t new_capacity = result->capacity == 0 ? 8 : result->capacity;
        if (result->capacity != 0) {
            new_capacity = result->capacity > maximum / 2
                               ? maximum : result->capacity * 2;
        }
        if (new_capacity > maximum) {
            new_capacity = maximum;
        }
        Match *grown = realloc(result->matches, new_capacity * sizeof(*grown));
        if (grown == NULL) {
            return STATUS_MEMORY_ERROR;
        }
        result->matches = grown;
        result->capacity = new_capacity;
    }
    result->matches[result->count].line = line;
    result->matches[result->count].column = column;
    ++result->count;
    return STATUS_OK;
}

/* Search byte-by-byte; overlapping occurrences are included. */
static Status find_matches(const unsigned char *data, size_t data_length,
                           const char *pattern, size_t pattern_length,
                           FileMatches *result) {
    if (data == NULL || pattern == NULL || pattern_length == 0 || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }

    size_t line = 1;
    size_t column = 1;
    for (size_t i = 0; i < data_length; ++i) {
        if (pattern_length <= data_length - i) {
            size_t j = 0;
            while (j < pattern_length &&
                   data[i + j] == (unsigned char)pattern[j]) {
                ++j;
            }
            if (j == pattern_length) {
                Status status = append_match(result, line, column);
                if (status != STATUS_OK) {
                    return status;
                }
            }
        }
        if (data[i] == (unsigned char)'\n') {
            if (line == SIZE_MAX) {
                return STATUS_OVERFLOW;
            }
            ++line;
            column = 1;
        } else {
            if (column == SIZE_MAX) {
                return STATUS_OVERFLOW;
            }
            ++column;
        }
    }
    return STATUS_OK;
}

static Status search_one_file(const char *pattern, size_t pattern_length,
                              const char *filename, FileMatches *result) {
    if (pattern == NULL || filename == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    result->filename = filename;
    unsigned char *data = NULL;
    size_t length = 0;
    Status status = read_file(filename, &data, &length);
    if (status == STATUS_OK) {
        status = find_matches(data, length, pattern, pattern_length, result);
    }
    free(data);
    return status;
}

/* Mandatory variadic function: pattern, file count, then all file paths. */
static Status search_files(const char *pattern, size_t file_count,
                           FileMatches **output, ...) {
    if (pattern == NULL || pattern[0] == '\0' || output == NULL ||
        file_count == 0 || file_count > SIZE_MAX / sizeof(FileMatches)) {
        return STATUS_INVALID_ARGUMENT;
    }
    *output = NULL;
    FileMatches *results = calloc(file_count, sizeof(*results));
    if (results == NULL) {
        return STATUS_MEMORY_ERROR;
    }

    size_t pattern_length = strlen(pattern);
    Status status = STATUS_OK;
    va_list args;
    va_start(args, output);
    for (size_t i = 0; i < file_count; ++i) {
        const char *filename = va_arg(args, const char *);
        status = search_one_file(pattern, pattern_length, filename, &results[i]);
        if (status != STATUS_OK) {
            break;
        }
    }
    va_end(args);

    if (status != STATUS_OK) {
        free_results(results, file_count);
        return status;
    }
    *output = results;
    return STATUS_OK;
}

static Status print_results(const FileMatches *files, size_t count) {
    if (files == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    for (size_t i = 0; i < count; ++i) {
        if (printf("FILE: %s\n", files[i].filename) < 0) {
            return STATUS_OUTPUT_ERROR;
        }
        if (files[i].count == 0 && printf("  No matches\n") < 0) {
            return STATUS_OUTPUT_ERROR;
        }
        for (size_t j = 0; j < files[i].count; ++j) {
            if (printf("  line %zu, column %zu\n",
                       files[i].matches[j].line,
                       files[i].matches[j].column) < 0) {
                return STATUS_OUTPUT_ERROR;
            }
        }
    }
    return STATUS_OK;
}

static const char *status_message(Status status) {
    switch (status) {
        case STATUS_OK: return "success";
        case STATUS_INVALID_ARGUMENT: return "invalid argument";
        case STATUS_OVERFLOW: return "size overflow";
        case STATUS_MEMORY_ERROR: return "memory allocation failed";
        case STATUS_FILE_OPEN_ERROR: return "cannot open file";
        case STATUS_FILE_READ_ERROR: return "cannot read file";
        case STATUS_FILE_CLOSE_ERROR: return "cannot close file";
        case STATUS_OUTPUT_ERROR: return "cannot write output";
    }
    return "unknown error";
}

int main(int argc, char *argv[]) {
    if (argc < 3 || argv == NULL || argv[1] == NULL || argv[1][0] == '\0') {
        fprintf(stderr, "Usage: %s PATTERN FILE [FILE ...]\n",
                argc > 0 && argv != NULL ? argv[0] : "task3");
        return EXIT_FAILURE;
    }

    /* Group the CLI paths into batches to call a variadic C function. */
    for (int i = 2; i < argc;) {
        int remaining = argc - i;
        size_t batch_size = remaining > 4 ? 4U : (size_t)remaining;
        FileMatches *results = NULL;
        Status status = STATUS_INVALID_ARGUMENT;
        switch (batch_size) {
            case 1:
                status = search_files(argv[1], 1, &results,
                                      (const char *)argv[i]);
                break;
            case 2:
                status = search_files(argv[1], 2, &results,
                                      (const char *)argv[i],
                                      (const char *)argv[i + 1]);
                break;
            case 3:
                status = search_files(argv[1], 3, &results,
                                      (const char *)argv[i],
                                      (const char *)argv[i + 1],
                                      (const char *)argv[i + 2]);
                break;
            case 4:
                status = search_files(argv[1], 4, &results,
                                      (const char *)argv[i],
                                      (const char *)argv[i + 1],
                                      (const char *)argv[i + 2],
                                      (const char *)argv[i + 3]);
                break;
            default:
                break;
        }
        if (status == STATUS_OK) {
            status = print_results(results, batch_size);
        }
        free_results(results, batch_size);
        if (status != STATUS_OK) {
            fprintf(stderr, "Error: %s\n", status_message(status));
            return EXIT_FAILURE;
        }
        i += (int)batch_size;
    }
    if (fflush(stdout) == EOF) {
        fprintf(stderr, "Error: cannot flush output\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
