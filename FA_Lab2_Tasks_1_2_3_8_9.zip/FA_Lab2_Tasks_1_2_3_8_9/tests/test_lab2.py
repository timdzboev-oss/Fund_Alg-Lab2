import pathlib
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
TASK1 = ROOT / "task1" / "task1"
TASK2 = ROOT / "task2" / "task2"


def run(*args):
    return subprocess.run([str(a) for a in args], capture_output=True, text=True, check=False)


class Task1Tests(unittest.TestCase):
    def test_length(self):
        self.assertEqual(run(TASK1, "-l", "Hello").stdout, "5\n")
        self.assertEqual(run(TASK1, "-l", "").stdout, "0\n")

    def test_reverse(self):
        self.assertEqual(run(TASK1, "-r", "Abcd").stdout, "dcbA\n")
        self.assertEqual(run(TASK1, "-r", "").stdout, "\n")

    def test_odd_uppercase(self):
        self.assertEqual(run(TASK1, "-u", "abcdef").stdout, "aBcDeF\n")
        self.assertEqual(run(TASK1, "-u", "A123b").stdout, "A123b\n")

    def test_group(self):
        self.assertEqual(run(TASK1, "-n", "b3$1a!2C").stdout, "312baC$!\n")
        self.assertEqual(run(TASK1, "-n", "").stdout, "\n")

    def test_concat_reproducible(self):
        result = run(TASK1, "-c", "AA", "42", "BB", "CC", "DD")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(run(TASK1, "-c", "AA", "42", "BB", "CC", "DD").stdout,
                         result.stdout)
        chunks = [result.stdout.strip()[i:i + 2] for i in range(0, 8, 2)]
        self.assertEqual(sorted(chunks), ["AA", "BB", "CC", "DD"])
        self.assertEqual(run(TASK1, "-c", "abc", "0").stdout, "abc\n")

    def test_invalid(self):
        bad_args = [
            ("-z", "x"), ("-l", "x", "y"), ("-c", "x"),
            ("-c", "x", "-1"), ("-c", "x", "4294967296000000000000"),
            ("-c", "x", "NaN"), ("-u",), ("/r", "abc"),
        ]
        for args in bad_args:
            with self.subTest(args=args):
                self.assertNotEqual(run(TASK1, *args).returncode, 0)


class Task2Tests(unittest.TestCase):
    RECORDS = (
        "12 John Smith 1000\n"
        "8 Alice Baker 1000\n"
        "4 George Smith 1500.50\n"
        "5 Emma Baker 2500\n"
        "2 Alice Baker 1000\n"
        "7 Julia Adams 999.25\n"
    )

    def check_sort(self, flag, expected_ids):
        with tempfile.TemporaryDirectory() as directory:
            input_path = pathlib.Path(directory) / "employees.txt"
            output_path = pathlib.Path(directory) / "output.txt"
            input_path.write_text(self.RECORDS)
            result = run(TASK2, input_path, flag, output_path)
            self.assertEqual(result.returncode, 0, result.stderr)
            lines = output_path.read_text().splitlines()
            self.assertEqual([int(line.split()[0]) for line in lines], expected_ids)
            self.assertEqual(len(lines), 6)

    def test_ascending(self):
        self.check_sort("-a", [7, 2, 8, 12, 4, 5])
        self.check_sort("/a", [7, 2, 8, 12, 4, 5])

    def test_descending(self):
        self.check_sort("-d", [5, 4, 12, 8, 2, 7])
        self.check_sort("/d", [5, 4, 12, 8, 2, 7])

    def test_invalid_records(self):
        for invalid in (
            "-1 Alice Baker 20\n", "3 Alice1 Baker 20\n",
            "3 Alice Baker -20\n", "3 Alice Baker nan\n",
            "3 Alice Baker inf\n", "3 Alice Baker 1e400\n",
            "3 Alice Baker 0x10\n", "3 Alice Baker\n",
            "3 Alice Baker 20 EXTRA\n", "429496729600 Alice Baker 20\n",
            "\n", "3 Alice Baker 20\x00garbage\n",
        ):
            with self.subTest(invalid=invalid):
                with tempfile.TemporaryDirectory() as directory:
                    input_path = pathlib.Path(directory) / "data.txt"
                    output_path = pathlib.Path(directory) / "out.txt"
                    input_path.write_bytes(invalid.encode())
                    result = run(TASK2, input_path, "-a", output_path)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn("line 1", result.stderr)
                    self.assertFalse(output_path.exists())

    def test_empty_and_unterminated_line(self):
        with tempfile.TemporaryDirectory() as directory:
            input_path = pathlib.Path(directory) / "data.txt"
            output_path = pathlib.Path(directory) / "out.txt"
            input_path.write_text("")
            self.assertEqual(run(TASK2, input_path, "-a", output_path).returncode, 0)
            self.assertEqual(output_path.read_text(), "")
            input_path.write_text("1 Jane Doe 9")
            self.assertEqual(run(TASK2, input_path, "-a", output_path).returncode, 0)
            self.assertEqual(output_path.read_text(), "1 Jane Doe 9\n")

    def test_long_record(self):
        with tempfile.TemporaryDirectory() as directory:
            input_path = pathlib.Path(directory) / "data.txt"
            output_path = pathlib.Path(directory) / "out.txt"
            input_path.write_text("1 " + "A" * 30000 + " Doe 9\n")
            result = run(TASK2, input_path, "-a", output_path)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("A" * 30000, output_path.read_text())

    def test_flags_and_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            input_path = pathlib.Path(directory) / "data.txt"
            output_path = pathlib.Path(directory) / "out.txt"
            input_path.write_text(self.RECORDS)
            self.assertNotEqual(run(TASK2, input_path, "-x", output_path).returncode, 0)
            self.assertNotEqual(run(TASK2, input_path, "-a").returncode, 0)
            self.assertNotEqual(run(TASK2, input_path / "missing", "-a", output_path).returncode, 0)
            self.assertNotEqual(run(TASK2, input_path, "-a", pathlib.Path(directory) / "missing" / "o").returncode, 0)

    def test_same_input_output_path(self):
        with tempfile.TemporaryDirectory() as directory:
            input_path = pathlib.Path(directory) / "employees.txt"
            input_path.write_text(self.RECORDS)
            result = run(TASK2, input_path, "-a", input_path)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(int(input_path.read_text().split()[0]), 7)


if __name__ == "__main__":
    unittest.main()
