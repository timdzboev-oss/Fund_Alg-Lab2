import pathlib
import random
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
TASK3 = ROOT / 'task3' / 'task3'
TASK8 = ROOT / 'task8' / 'task8'
TASK9 = ROOT / 'task9' / 'task9'


def run(path, *args):
    return subprocess.run([str(path), *map(str, args)],
                          capture_output=True, text=True, check=False)


class Task3Tests(unittest.TestCase):
    def test_overlap_and_terminating_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'text.txt'
            p.write_text('banana\nanana\n', encoding='utf-8')
            x = run(TASK3, 'ana', p)
            self.assertEqual(x.returncode, 0, x.stderr)
            self.assertIn('line 1, column 2', x.stdout)
            self.assertIn('line 1, column 4', x.stdout)
            self.assertIn('line 2, column 1', x.stdout)
            self.assertIn('line 2, column 3', x.stdout)
            self.assertEqual(x.stdout.count('column'), 4)

    def test_multiline_and_tabs(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'text.txt'
            p.write_bytes(b'xx\tA\nBzz\nA\nB')
            x = run(TASK3, 'A\nB', p)
            self.assertEqual(x.returncode, 0, x.stderr)
            self.assertIn('line 1, column 4', x.stdout)
            self.assertIn('line 3, column 1', x.stdout)
            self.assertEqual(x.stdout.count('column'), 2)

    def test_file_bigger_than_initial_buffer(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'long.txt'
            p.write_bytes(b'a' * 12000 + b'End')
            x = run(TASK3, 'End', p)
            self.assertEqual(x.returncode, 0, x.stderr)
            self.assertIn('line 1, column 12001', x.stdout)

    def test_files_count_greater_than_four(self):
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for i in range(7):
                p = pathlib.Path(tmp) / f'text{i}.txt'
                p.write_text('aba', encoding='utf-8')
                paths.append(p)
            x = run(TASK3, 'a', *paths)
            self.assertEqual(x.returncode, 0, x.stderr)
            self.assertEqual(x.stdout.count('FILE:'), 7)
            self.assertEqual(x.stdout.count('column'), 14)

    def test_invalid_and_no_matches(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = pathlib.Path(tmp) / 'empty.txt'
            p.write_bytes(b'')
            self.assertIn('No matches', run(TASK3, 'text', p).stdout)
            self.assertNotEqual(run(TASK3, '', p).returncode, 0)
            self.assertNotEqual(run(TASK3, 'x', str(p) + 'notfound').returncode, 0)


class Task8Tests(unittest.TestCase):
    def test_examples(self):
        pairs = [
            (2, ['1111', '1'], '10000'),
            (10, ['0001', '000002', '0000'], '3'),
            (16, ['FFFF', '1', 'abc'], '10abc'),
            (36, ['z', '1'], '10'),
            (10, ['0', '0'], '0'),
        ]
        for base, numbers, result in pairs:
            with self.subTest(base=base, numbers=numbers):
                proc = run(TASK8, base, *numbers)
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertEqual(proc.stdout, result + '\n')

    def test_long_numbers(self):
        proc = run(TASK8, 10, '9' * 10000, '1')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, '1' + '0' * 10000 + '\n')

    def test_many_numbers_and_random(self):
        rng = random.Random(123)
        for base in [2, 7, 10, 16, 36]:
            values = [rng.randrange(0, 100000000) for _ in range(16)]
            digits = '0123456789abcdefghijklmnopqrstuvwxyz'
            def encode(value):
                if value == 0:
                    return '0'
                out = ''
                while value:
                    value, digit = divmod(value, base)
                    out = digits[digit] + out
                return out
            proc = run(TASK8, base, *map(encode, values))
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(proc.stdout.strip(), encode(sum(values)))

    def test_invalid(self):
        for args in [(1, '1'), (37, '1'), (2, '102'), (10, '-1'),
                     (16, '0x10'), (36, 'zz!'), (10, '')]:
            with self.subTest(args=args):
                self.assertNotEqual(run(TASK8, *args).returncode, 0)


class Task9Tests(unittest.TestCase):
    def test_binary(self):
        proc = run(TASK9, 2, '0.5', '0.1', '0.125', '0.25', '0.2', '0.0009765625')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        outcomes = [line.split(' -> ')[1].startswith('finite')
                    for line in proc.stdout.splitlines()]
        self.assertEqual(outcomes, [True, False, True, True, False, True])

    def test_various_bases(self):
        cases = [
            (3, '0.5', False), (5, '0.2', True),
            (5, '0.1', False), (10, '0.1', True),
            (20, '0.05', True), (4, '0.125', True),
            (36, '0.1', False), (25, '0.04', True),
            (7, '0.5', False), (2, '0.3', False),
        ]
        for base, value, finite in cases:
            with self.subTest(base=base, value=value):
                proc = run(TASK9, base, value)
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertEqual(' -> finite ' in proc.stdout, finite)

    def test_scientific_and_smallest_floats(self):
        proc = run(TASK9, 10, '1e-30', '5e-324', '1e-300')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout.count(' -> finite '), 3)

    def test_invalid(self):
        for args in [(10, '0'), (2, '1'), (2, '1.2'),
                     (10, '1e9999'), (10, '-0.5'), (2, 'nan'),
                     (2, '0x1p-1'), (2, '0.3garbage'), (2, '0.0')]:
            with self.subTest(args=args):
                self.assertNotEqual(run(TASK9, *args).returncode, 0)


if __name__ == '__main__':
    unittest.main()
