#include <ctype.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    unsigned int id;
    char *first_name;
    char *last_name;
    double salary;
} Employee;

typedef enum {
    STATUS_OK = 0,
    STATUS_INVALID_ARGUMENT,
    STATUS_INVALID_DATA,
    STATUS_OVERFLOW,
    STATUS_OUT_OF_MEMORY,
    STATUS_CANNOT_OPEN_FILE,
    STATUS_READ_ERROR,
    STATUS_WRITE_ERROR,
    STATUS_END_OF_FILE
} Status;

static void free_employee(Employee *employee) {
    if (employee == NULL) {
        return;
    }
    free(employee->first_name);
    free(employee->last_name);
    employee->first_name = NULL;
    employee->last_name = NULL;
}

static void free_employees(Employee *employees, size_t count) {
    if (employees == NULL) {
        return;
    }
    for (size_t i = 0; i < count; ++i) {
        free_employee(&employees[i]);
    }
    free(employees);
}

/* Reads a complete line of arbitrary length using standard C11 facilities. */
static Status read_line(FILE *file, char **line) {
    if (file == NULL || line == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *line = NULL;

    size_t capacity = 128;
    size_t length = 0;
    char *buffer = malloc(capacity);
    if (buffer == NULL) {
        return STATUS_OUT_OF_MEMORY;
    }

    int ch;
    while ((ch = fgetc(file)) != EOF && ch != '\n') {
        if (ch == '\0') {
            free(buffer);
            return STATUS_INVALID_DATA;
        }
        if (length == capacity - 1) {
            if (capacity > SIZE_MAX / 2) {
                free(buffer);
                return STATUS_OVERFLOW;
            }
            size_t new_capacity = capacity * 2;
            char *larger = realloc(buffer, new_capacity);
            if (larger == NULL) {
                free(buffer);
                return STATUS_OUT_OF_MEMORY;
            }
            buffer = larger;
            capacity = new_capacity;
        }
        buffer[length++] = (char)ch;
    }
    if (ferror(file)) {
        free(buffer);
        return STATUS_READ_ERROR;
    }
    if (ch == EOF && length == 0) {
        free(buffer);
        return STATUS_END_OF_FILE;
    }

    buffer[length] = '\0';
    *line = buffer;
    return STATUS_OK;
}

static char *next_token(char **cursor) {
    if (cursor == NULL || *cursor == NULL) {
        return NULL;
    }
    char *current = *cursor;
    while (isspace((unsigned char)*current)) {
        ++current;
    }
    if (*current == '\0') {
        *cursor = current;
        return NULL;
    }

    char *begin = current;
    while (*current != '\0' && !isspace((unsigned char)*current)) {
        ++current;
    }
    if (*current != '\0') {
        *current++ = '\0';
    }
    *cursor = current;
    return begin;
}

static Status parse_unsigned_id(const char *text, unsigned int *result) {
    if (text == NULL || result == NULL || *text == '\0') {
        return STATUS_INVALID_ARGUMENT;
    }
    unsigned int value = 0;
    for (size_t i = 0; text[i] != '\0'; ++i) {
        if (text[i] < '0' || text[i] > '9') {
            return STATUS_INVALID_DATA;
        }
        unsigned int digit = (unsigned int)(text[i] - '0');
        if (value > (UINT_MAX - digit) / 10U) {
            return STATUS_OVERFLOW;
        }
        value = value * 10U + digit;
    }
    *result = value;
    return STATUS_OK;
}

static int is_valid_name(const char *text) {
    if (text == NULL || *text == '\0') {
        return 0;
    }
    for (size_t i = 0; text[i] != '\0'; ++i) {
        char ch = text[i];
        if (!((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))) {
            return 0;
        }
    }
    return 1;
}

/* Check decimal syntax before strtod: reject nan, inf and hexadecimal input. */
static int is_decimal_number(const char *text) {
    if (text == NULL || *text == '\0') {
        return 0;
    }
    size_t i = 0;
    if (text[i] == '+') {
        ++i;
    }

    size_t digits = 0;
    while (text[i] >= '0' && text[i] <= '9') {
        ++digits;
        ++i;
    }
    if (text[i] == '.') {
        ++i;
        while (text[i] >= '0' && text[i] <= '9') {
            ++digits;
            ++i;
        }
    }
    if (digits == 0) {
        return 0;
    }
    if (text[i] == 'e' || text[i] == 'E') {
        ++i;
        if (text[i] == '+' || text[i] == '-') {
            ++i;
        }
        size_t exp_digits = 0;
        while (text[i] >= '0' && text[i] <= '9') {
            ++exp_digits;
            ++i;
        }
        if (exp_digits == 0) {
            return 0;
        }
    }
    return text[i] == '\0';
}

static Status parse_salary(const char *text, double *result) {
    if (text == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    if (!is_decimal_number(text)) {
        return STATUS_INVALID_DATA;
    }

    char *end = NULL;
    double value = strtod(text, &end);
    if (end == text || *end != '\0' || !isfinite(value) || value < 0.0) {
        return STATUS_INVALID_DATA;
    }
    *result = value;
    return STATUS_OK;
}

static Status copy_name(const char *text, char **result) {
    if (text == NULL || result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    size_t length = strlen(text);
    if (length == SIZE_MAX) {
        return STATUS_OVERFLOW;
    }
    char *copy = malloc(length + 1);
    if (copy == NULL) {
        return STATUS_OUT_OF_MEMORY;
    }
    memcpy(copy, text, length + 1);
    *result = copy;
    return STATUS_OK;
}

static Status parse_employee(char *line, Employee *employee) {
    if (line == NULL || employee == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    employee->id = 0;
    employee->salary = 0.0;
    employee->first_name = NULL;
    employee->last_name = NULL;

    char *cursor = line;
    char *id_text = next_token(&cursor);
    char *first_name_text = next_token(&cursor);
    char *last_name_text = next_token(&cursor);
    char *salary_text = next_token(&cursor);
    if (id_text == NULL || first_name_text == NULL || last_name_text == NULL ||
        salary_text == NULL || next_token(&cursor) != NULL) {
        return STATUS_INVALID_DATA;
    }
    if (!is_valid_name(first_name_text) || !is_valid_name(last_name_text)) {
        return STATUS_INVALID_DATA;
    }

    Status status = parse_unsigned_id(id_text, &employee->id);
    if (status != STATUS_OK) {
        return status;
    }
    status = parse_salary(salary_text, &employee->salary);
    if (status != STATUS_OK) {
        return status;
    }

    status = copy_name(first_name_text, &employee->first_name);
    if (status != STATUS_OK) {
        return status;
    }
    status = copy_name(last_name_text, &employee->last_name);
    if (status != STATUS_OK) {
        free_employee(employee);
    }
    return status;
}

static Status push_employee(Employee **array, size_t *length, size_t *capacity,
                            const Employee *employee) {
    if (array == NULL || length == NULL || capacity == NULL || employee == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    if (*length == *capacity) {
        size_t new_capacity = *capacity == 0 ? 8 : *capacity;
        if (*capacity != 0) {
            if (*capacity > SIZE_MAX / 2) {
                return STATUS_OVERFLOW;
            }
            new_capacity *= 2;
        }
        if (new_capacity > SIZE_MAX / sizeof(**array)) {
            return STATUS_OVERFLOW;
        }
        Employee *larger = realloc(*array, new_capacity * sizeof(**array));
        if (larger == NULL) {
            return STATUS_OUT_OF_MEMORY;
        }
        *array = larger;
        *capacity = new_capacity;
    }
    (*array)[*length] = *employee;
    ++*length;
    return STATUS_OK;
}

static Status load_employees(const char *path, Employee **result, size_t *count,
                             size_t *error_line) {
    if (path == NULL || result == NULL || count == NULL || error_line == NULL || *path == '\0') {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    *count = 0;
    *error_line = 0;

    FILE *file = fopen(path, "r");
    if (file == NULL) {
        return STATUS_CANNOT_OPEN_FILE;
    }

    Employee *employees = NULL;
    size_t length = 0;
    size_t capacity = 0;
    Status status = STATUS_OK;
    for (;;) {
        char *line = NULL;
        status = read_line(file, &line);
        if (status == STATUS_END_OF_FILE) {
            status = STATUS_OK;
            break;
        }
        if (status != STATUS_OK) {
            *error_line = length + 1;
            break;
        }

        Employee employee;
        status = parse_employee(line, &employee);
        free(line);
        if (status != STATUS_OK) {
            *error_line = length + 1;
            free_employee(&employee);
            break;
        }
        status = push_employee(&employees, &length, &capacity, &employee);
        if (status != STATUS_OK) {
            *error_line = length + 1;
            free_employee(&employee);
            break;
        }
    }
    if (fclose(file) != 0 && status == STATUS_OK) {
        status = STATUS_READ_ERROR;
    }
    if (status != STATUS_OK) {
        free_employees(employees, length);
        return status;
    }

    *result = employees;
    *count = length;
    return STATUS_OK;
}

/*
 * The statement says to use epsilon in floating-point comparisons, but also
 * defines ties as genuinely equal salaries. DBL_TRUE_MIN is the smallest
 * strictly positive representable double, so comparing with it treats only
 * equal finite double values as ties and preserves qsort's transitivity.
 */
static int compare_salary(double a, double b, double epsilon) {
    if (epsilon > 0.0 && fabs(a - b) < epsilon) {
        return 0;
    }
    return a < b ? -1 : 1;
}

static int compare_employees_ascending(const void *a, const void *b) {
    const Employee *left = a;
    const Employee *right = b;
    int comparison = compare_salary(left->salary, right->salary, DBL_TRUE_MIN);
    if (comparison != 0) {
        return comparison;
    }
    comparison = strcmp(left->last_name, right->last_name);
    if (comparison != 0) {
        return comparison < 0 ? -1 : 1;
    }
    comparison = strcmp(left->first_name, right->first_name);
    if (comparison != 0) {
        return comparison < 0 ? -1 : 1;
    }
    if (left->id == right->id) {
        return 0;
    }
    return left->id < right->id ? -1 : 1;
}

static int compare_employees_descending(const void *a, const void *b) {
    return -compare_employees_ascending(a, b);
}

static Status sort_employees(Employee *employees, size_t count, int ascending) {
    if ((employees == NULL && count != 0) || (ascending != 0 && ascending != 1)) {
        return STATUS_INVALID_ARGUMENT;
    }
    if (count > SIZE_MAX / sizeof(*employees)) {
        return STATUS_OVERFLOW;
    }
    if (count > 1) {
        qsort(employees, count, sizeof(*employees),
              ascending ? compare_employees_ascending : compare_employees_descending);
    }
    return STATUS_OK;
}

static Status write_employees(const char *path, const Employee *employees, size_t count) {
    if (path == NULL || *path == '\0' || (employees == NULL && count != 0)) {
        return STATUS_INVALID_ARGUMENT;
    }
    FILE *file = fopen(path, "w");
    if (file == NULL) {
        return STATUS_CANNOT_OPEN_FILE;
    }
    Status status = STATUS_OK;
    for (size_t i = 0; i < count; ++i) {
        if (fprintf(file, "%u %s %s %.17g\n", employees[i].id,
                    employees[i].first_name, employees[i].last_name,
                    employees[i].salary) < 0) {
            status = STATUS_WRITE_ERROR;
            break;
        }
    }
    if (fclose(file) != 0) {
        status = STATUS_WRITE_ERROR;
    }
    return status;
}

static const char *status_description(Status status) {
    switch (status) {
        case STATUS_OK: return "success";
        case STATUS_INVALID_ARGUMENT: return "invalid argument";
        case STATUS_INVALID_DATA: return "invalid employee record";
        case STATUS_OVERFLOW: return "numeric or allocation-size overflow";
        case STATUS_OUT_OF_MEMORY: return "memory allocation failed";
        case STATUS_CANNOT_OPEN_FILE: return "cannot open file";
        case STATUS_READ_ERROR: return "file read or close failed";
        case STATUS_WRITE_ERROR: return "file write or close failed";
        case STATUS_END_OF_FILE: return "end of file";
    }
    return "unknown error";
}

int main(int argc, char *argv[]) {
    if (argc != 4 || argv == NULL || argv[1] == NULL || argv[2] == NULL || argv[3] == NULL) {
        fprintf(stderr, "Usage: task2 INPUT_FILE [-a|-d|/a|/d] OUTPUT_FILE\n");
        return EXIT_FAILURE;
    }
    const char *flag = argv[2];
    if (!((flag[0] == '-' || flag[0] == '/') &&
          (flag[1] == 'a' || flag[1] == 'd') && flag[2] == '\0')) {
        fprintf(stderr, "Error: flag must be -a, -d, /a, or /d\n");
        return EXIT_FAILURE;
    }

    Employee *employees = NULL;
    size_t count = 0;
    size_t error_line = 0;
    Status status = load_employees(argv[1], &employees, &count, &error_line);
    if (status == STATUS_OK) {
        status = sort_employees(employees, count, flag[1] == 'a');
    }
    if (status == STATUS_OK) {
        status = write_employees(argv[3], employees, count);
    }
    free_employees(employees, count);

    if (status != STATUS_OK) {
        fprintf(stderr, "Error: %s", status_description(status));
        if (error_line != 0) {
            fprintf(stderr, " (line %zu)", error_line);
        }
        fputc('\n', stderr);
        return EXIT_FAILURE;
    }
    if (printf("Sorted %zu employee(s) into %s\n", count, argv[3]) < 0 || fflush(stdout) == EOF) {
        fprintf(stderr, "Error: failed to write to stdout\n");
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
