#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    STATUS_OK = 0,
    STATUS_INVALID_ARGUMENT,
    STATUS_OVERFLOW,
    STATUS_MEMORY_ERROR,
    STATUS_OUTPUT_ERROR
} Status;

static int digit_value(char ch) {
    if (ch >= '0' && ch <= '9') {
        return ch - '0';
    }
    if (ch >= 'a' && ch <= 'z') {
        return ch - 'a' + 10;
    }
    if (ch >= 'A' && ch <= 'Z') {
        return ch - 'A' + 10;
    }
    return -1;
}

static char digit_char(unsigned int digit) {
    return digit < 10U ? (char)('0' + digit)
                       : (char)('a' + digit - 10U);
}

static Status validate_number(const char *number, unsigned int base) {
    if (number == NULL || *number == '\0' || base < 2U || base > 36U) {
        return STATUS_INVALID_ARGUMENT;
    }
    for (size_t i = 0; number[i] != '\0'; ++i) {
        int digit = digit_value(number[i]);
        if (digit < 0 || (unsigned int)digit >= base) {
            return STATUS_INVALID_ARGUMENT;
        }
    }
    return STATUS_OK;
}

/* Column addition without conversion to any built-in numeric type. */
static Status add_two_numbers(const char *left, const char *right,
                              unsigned int base, char **result) {
    if (result == NULL) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    Status status = validate_number(left, base);
    if (status != STATUS_OK) {
        return status;
    }
    status = validate_number(right, base);
    if (status != STATUS_OK) {
        return status;
    }

    size_t left_length = strlen(left);
    size_t right_length = strlen(right);
    size_t maximum = left_length > right_length ? left_length : right_length;
    if (maximum > SIZE_MAX - 2) {
        return STATUS_OVERFLOW;
    }
    size_t capacity = maximum + 2;
    char *buffer = malloc(capacity);
    if (buffer == NULL) {
        return STATUS_MEMORY_ERROR;
    }

    size_t position = capacity - 1;
    buffer[position] = '\0';
    unsigned int carry = 0;
    while (left_length > 0 || right_length > 0 || carry != 0) {
        unsigned int sum = carry;
        if (left_length > 0) {
            sum += (unsigned int)digit_value(left[--left_length]);
        }
        if (right_length > 0) {
            sum += (unsigned int)digit_value(right[--right_length]);
        }
        buffer[--position] = digit_char(sum % base);
        carry = sum / base;
    }

    /* Remove leading zeros without requiring any extra allocation. */
    while (buffer[position] == '0' && buffer[position + 1] != '\0') {
        ++position;
    }
    size_t out_length = capacity - position;
    for (size_t i = 0; i < out_length; ++i) {
        buffer[i] = buffer[position + i];
    }
    *result = buffer;
    return STATUS_OK;
}

/* Required variadic function: base, quantity, and strings to add. */
static Status sum_numbers(unsigned int base, size_t count, char **result, ...) {
    if (result == NULL || count == 0 || base < 2U || base > 36U) {
        return STATUS_INVALID_ARGUMENT;
    }
    *result = NULL;
    char *total = malloc(2);
    if (total == NULL) {
        return STATUS_MEMORY_ERROR;
    }
    total[0] = '0';
    total[1] = '\0';

    Status status = STATUS_OK;
    va_list args;
    va_start(args, result);
    for (size_t i = 0; i < count; ++i) {
        const char *current = va_arg(args, const char *);
        char *next = NULL;
        status = add_two_numbers(total, current, base, &next);
        if (status != STATUS_OK) {
            break;
        }
        free(total);
        total = next;
    }
    va_end(args);

    if (status != STATUS_OK) {
        free(total);
        return status;
    }
    *result = total;
    return STATUS_OK;
}

static Status parse_base(const char *text, unsigned int *base) {
    if (text == NULL || base == NULL || text[0] == '\0') {
        return STATUS_INVALID_ARGUMENT;
    }
    unsigned int value = 0;
    for (size_t i = 0; text[i] != '\0'; ++i) {
        if (text[i] < '0' || text[i] > '9') {
            return STATUS_INVALID_ARGUMENT;
        }
        value = value * 10U + (unsigned int)(text[i] - '0');
        if (value > 36U) {
            return STATUS_INVALID_ARGUMENT;
        }
    }
    if (value < 2U) {
        return STATUS_INVALID_ARGUMENT;
    }
    *base = value;
    return STATUS_OK;
}

static const char *status_message(Status status) {
    switch (status) {
        case STATUS_OK: return "success";
        case STATUS_INVALID_ARGUMENT: return "invalid argument or digit";
        case STATUS_OVERFLOW: return "size overflow";
        case STATUS_MEMORY_ERROR: return "memory allocation failed";
        case STATUS_OUTPUT_ERROR: return "cannot write result";
    }
    return "unknown error";
}

int main(int argc, char *argv[]) {
    if (argc < 3 || argv == NULL || argv[1] == NULL) {
        fprintf(stderr, "Usage: %s BASE NUMBER [NUMBER ...]\n",
                argc > 0 && argv != NULL ? argv[0] : "task8");
        return EXIT_FAILURE;
    }
    unsigned int base = 0;
    Status status = parse_base(argv[1], &base);
    if (status != STATUS_OK) {
        fprintf(stderr, "Error: base must be in [2, 36]\n");
        return EXIT_FAILURE;
    }

    char *total = malloc(2);
    if (total == NULL) {
        fprintf(stderr, "Error: memory allocation failed\n");
        return EXIT_FAILURE;
    }
    total[0] = '0';
    total[1] = '\0';

    /* Runtime CLI length is arbitrary; use repeated variadic calls in batches. */
    for (int i = 2; i < argc;) {
        size_t batch = (argc - i > 4) ? 4U : (size_t)(argc - i);
        char *partial = NULL;
        switch (batch) {
            case 1:
                status = sum_numbers(base, 1, &partial,
                                     (const char *)argv[i]);
                break;
            case 2:
                status = sum_numbers(base, 2, &partial,
                                     (const char *)argv[i],
                                     (const char *)argv[i + 1]);
                break;
            case 3:
                status = sum_numbers(base, 3, &partial,
                                     (const char *)argv[i],
                                     (const char *)argv[i + 1],
                                     (const char *)argv[i + 2]);
                break;
            case 4:
                status = sum_numbers(base, 4, &partial,
                                     (const char *)argv[i],
                                     (const char *)argv[i + 1],
                                     (const char *)argv[i + 2],
                                     (const char *)argv[i + 3]);
                break;
            default:
                status = STATUS_INVALID_ARGUMENT;
                break;
        }
        if (status != STATUS_OK) {
            free(partial);
            break;
        }
        char *next = NULL;
        status = add_two_numbers(total, partial, base, &next);
        free(partial);
        if (status != STATUS_OK) {
            break;
        }
        free(total);
        total = next;
        i += (int)batch;
    }

    if (status == STATUS_OK) {
        if (printf("%s\n", total) < 0 || fflush(stdout) == EOF) {
            status = STATUS_OUTPUT_ERROR;
        }
    }
    free(total);
    if (status != STATUS_OK) {
        fprintf(stderr, "Error: %s\n", status_message(status));
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
